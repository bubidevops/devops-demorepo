#!/bin/bash

sudo yum install -y docker
sudo service docker start